package midend.type;

public enum IrValueType {
    I32_ARR,
    I8_ARR,
    I32,
    I8,
    VOID,
    LABEL,
    WRITEBACK,

}
