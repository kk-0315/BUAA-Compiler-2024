package midend.symbols;

import midend.IrValue;
import midend.type.IrValueType;

import java.util.ArrayList;

public class IrSymbolFunc extends IrSymbol{
    private ArrayList<IrSymbol> params;


    public IrSymbolFunc(String name, IrValue irValue) {
        super(name,irValue);
        params=new ArrayList<>();
    }
    public void addParam(IrSymbol irSymbol){
        params.add(irSymbol);
    }

}
