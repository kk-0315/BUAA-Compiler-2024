package midend.value.constant;

import midend.IrUser;
import midend.IrValue;
import midend.type.IrValueType;

public class IrConstant extends IrValue {

    public IrConstant(IrValueType irValueType){
        super(irValueType);

    }
}
