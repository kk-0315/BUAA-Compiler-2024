package midend.value.function;

import frontend.parser.specificUnit.FuncFParams;
import midend.IrUser;
import midend.IrValue;
import midend.type.IrValueType;
import midend.value.basicBlock.IrBasicBlock;

import java.util.ArrayList;

public class IrFunction extends IrValue {

    private ArrayList<IrParam> irParams;
    private ArrayList<IrBasicBlock> irBasicBlocks;


    public IrFunction(IrValueType irValueType, String name) {
        super(irValueType, name);
        this.irParams=new ArrayList<>();
        this.irBasicBlocks=new ArrayList<>();
    }

    public void addIrBasicBlock(IrBasicBlock irBasicBlock){
        irBasicBlocks.add(irBasicBlock);
    }
    public void addAllBasicBlocks(ArrayList<IrBasicBlock> irBasicBlocks){
        this.irBasicBlocks.addAll(irBasicBlocks);
    }
    public void addIrParam(IrParam irParam){
        irParams.add(irParam);
    }
    public int getIrParamSize(){
        return irParams.size();
    }
    public ArrayList<IrBasicBlock> getIrBasicBlocks(){
        return irBasicBlocks;
    }
    public IrParam getIndexParam(int index){
        for(IrParam irParam:irParams){
            if(irParam.getRank()==index){
                return irParam;
            }
        }
        return null;
    }
    public ArrayList<IrParam> getIrParams(){
        return irParams;
    }
    @Override
    public String toString(){
        StringBuilder sb=new StringBuilder();
        sb.append("define ");
        sb.append("dso_local ");
        sb.append(getIrValueType().toString().toLowerCase());
        sb.append(" ");
        sb.append(getName());
        sb.append('(');
        if(!irParams.isEmpty()){

            sb.append(irParams.get(0).toString());
            for(int i=1;i<irParams.size();i++){
                sb.append(',').append(' ');
                sb.append(irParams.get(i).toString());
            }
        }
        sb.append(')');
        sb.append(" {\n");
        for(IrBasicBlock irBasicBlock:irBasicBlocks){
            sb.append(irBasicBlock.toString());
        }
        sb.append("}\n");
        return sb.toString();
    }
}
