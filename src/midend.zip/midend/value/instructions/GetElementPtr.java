package midend.value.instructions;

public class GetElementPtr {
}
