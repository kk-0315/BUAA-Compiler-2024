package midend.value.instructions;

import midend.IrUser;
import midend.type.IrValueType;

public class IrInstruction extends IrUser {
    private IrInstructionType irInstructionType;


    public IrInstruction(IrValueType irValueType, int opNum,IrInstructionType irInstructionType) {
        super(irValueType, opNum);
        this.irInstructionType=irInstructionType;
    }
    public IrInstruction(IrValueType irValueType,String name, int opNum,IrInstructionType irInstructionType) {
        super(irValueType,name,opNum);
        this.irInstructionType=irInstructionType;
    }
    public IrInstructionType getIrInstructionType(){
        return irInstructionType;
    }

}
