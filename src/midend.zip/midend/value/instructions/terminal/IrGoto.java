package midend.value.instructions.terminal;

import midend.type.IrValueType;
import midend.value.instructions.IrInstruction;
import midend.value.instructions.IrInstructionType;
import midend.value.instructions.IrLabel;

public class IrGoto extends IrInstruction {
    public IrGoto(IrLabel irLabel) {
        super(IrValueType.LABEL, 1, IrInstructionType.Goto);
        this.setIrUses(irLabel,0);
    }
    @Override
    public String toString(){
        StringBuilder sb=new StringBuilder();
        sb.append('\t');
        sb.append("goto ").append(getOperandFromIndex(0).getName()).append('\n');
        return sb.toString();
    }
}
