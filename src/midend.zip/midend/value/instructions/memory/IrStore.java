package midend.value.instructions.memory;

import midend.IrValue;
import midend.type.IrValueType;
import midend.value.instructions.IrInstruction;
import midend.value.instructions.IrInstructionType;

public class IrStore extends IrInstruction {
    private IrValue storeValue;
    private IrValue storeAddress;
    private IrValue offset;
    public IrStore(IrValue storeValue,IrValue storeAddress,IrValue offset) {
        super(IrValueType.VOID, 2, IrInstructionType.Store);
        this.setIrUses(storeValue,0);
        this.setIrUses(storeAddress,1);
        this.offset=offset;
        this.storeValue=storeValue;
        this.storeAddress=storeAddress;
    }
    public IrValue getStoreValue(){
        return storeValue;
    }
    public IrValue getStoreAddress(){
        return storeAddress;
    }
    public IrValue getOffset(){
        return offset;
    }
    @Override
    public String toString(){
        StringBuilder sb=new StringBuilder();
        sb.append("\t");
        sb.append("store ");
        sb.append(storeValue.getIrValueType().toString().toLowerCase());
        sb.append(' ');
        sb.append(storeValue.getName());
        sb.append(", ");
        sb.append(storeAddress.getIrValueType().toString().toLowerCase());
        sb.append("* ");
        sb.append(storeAddress.getName());
        if(offset!=null){
            sb.append("[").append(offset.getName()).append("]");
        }
        sb.append('\n');
        return sb.toString();
    }
}
