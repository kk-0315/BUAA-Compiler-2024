package midend.value.instructions.memory;

import midend.IrValue;
import midend.type.IrValueType;
import midend.value.instructions.IrInstruction;
import midend.value.instructions.IrInstructionType;

public class IrLoad extends IrInstruction {

    private IrValue offset; //数组内exp，如有
    public IrLoad(IrValueType irValueType, String name, IrInstructionType irInstructionType,IrValue irValue) {
        super(irValueType, name, 1, irInstructionType);
        this.setIrUses(irValue,0);
//        if(irValue.getDimensionIndex()!=null){
//            this.setDimensionNum(0);
//            this.setDimensionIndex(null);
//        }else {
//            this.setDimensionNum(irValue.getDimensionNum());
//        }
//
//        this.offset=irValue.getDimensionIndex();
    }
    public void setOffset(IrValue offset){
        this.offset=offset;
    }



    public IrValue getOffset(){
        return offset;
    }

    @Override
    public String toString(){
        StringBuilder sb=new StringBuilder();
        sb.append("\t");
        sb.append(getName());
        sb.append(" = ");
        sb.append("load ");
        sb.append(getIrValueType());
        sb.append(',').append(' ');
        sb.append(getOperandFromIndex(0).getIrValueType()).append(' ');
        sb.append(getOperandFromIndex(0).getName());
        if(offset!=null){
            sb.append('[').append(offset.getName()).append(']');
        }
        sb.append('\n');
        return sb.toString();
    }
}
