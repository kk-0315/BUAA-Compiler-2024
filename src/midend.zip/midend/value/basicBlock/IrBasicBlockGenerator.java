package midend.value.basicBlock;

import frontend.lexer.Word;
import frontend.parser.specificUnit.*;
import midend.IrValue;
import midend.symbols.LinkSymbolTable;
import midend.type.IrValueType;
import midend.value.function.IrFunctionCnt;
import midend.value.instructions.*;
import midend.value.instructions.memory.IrStore;
import midend.value.instructions.terminal.IrBr;
import midend.value.instructions.terminal.IrGoto;

import java.util.ArrayList;

public class IrBasicBlockGenerator {
    private LinkSymbolTable linkSymbolTable;
    private IrFunctionCnt functionCnt;
    private Block block; //三种会形成基本块的语句
    private ForLoopStmt forLoopStmt; //三种会形成基本块的语句
    private IfStmt ifStmt; //三种会形成基本块的语句
    private ArrayList<BlockItem> blockItems;
    private ArrayList<IrBasicBlock> basicBlocks = new ArrayList<>();
    private IrLabel nextStepForLoop;
    private IrLabel endLabelForLoop;
    private IrLabel endLabelForIf;
    public IrBasicBlockGenerator(LinkSymbolTable linkSymbolTable, Block block, IrFunctionCnt functionCnt,IrLabel nextStepForLoop,IrLabel endLabelForLoop) {
        this.linkSymbolTable = linkSymbolTable;
        this.functionCnt = functionCnt;
        this.block = block;
        this.blockItems = this.block.getBlockItems();
        this.nextStepForLoop=nextStepForLoop;
        this.endLabelForLoop=endLabelForLoop;
    }
//    public IrBasicBlockGenerator(LinkSymbolTable linkSymbolTable, Block block, IrFunctionCnt functionCnt,IrLabel nextStepForLoop,IrLabel endLabelForLoop) {
//        this.linkSymbolTable = linkSymbolTable;
//        this.functionCnt = functionCnt;
//        this.block = block;
//        this.blockItems = this.block.getBlockItems();
//        this.nextStepForLoop=nextStepForLoop;
//    }
    public IrBasicBlockGenerator(LinkSymbolTable linkSymbolTable, ForLoopStmt forLoopStmt, IrFunctionCnt functionCnt) {
        this.linkSymbolTable = linkSymbolTable;
        this.functionCnt = functionCnt;
        this.forLoopStmt = forLoopStmt;
    }
    public IrBasicBlockGenerator(LinkSymbolTable linkSymbolTable, IfStmt ifStmt, IrFunctionCnt functionCnt,IrLabel nextStepForLoop,IrLabel endLabelForLoop) {
        this.linkSymbolTable = linkSymbolTable;
        this.functionCnt = functionCnt;
        this.ifStmt = ifStmt;
        this.nextStepForLoop=nextStepForLoop;
        this.endLabelForLoop=endLabelForLoop;
    }
    public ArrayList<IrBasicBlock> generateIrBasicBlock() {
        if(block!=null){
            return generateIrBasicBlockFromBlock();
        }else if(ifStmt!=null){
            return generateIrBasicBlockFromIfStmt();
        }else {
            return generateIrBasicBlockFromForLoopStmt();
        }
    }
    public void generateBasicBlockFromEqExp(EqExp eqExp,IrLabel ifLabel,int size,IrLabel destLabel,boolean isLoop){
        IrBasicBlock irBasicBlock=new IrBasicBlock();
        ArrayList<IrInstruction> instructions1=new ArrayList<>();
        IrValue left=null,right=null;
        left=eqExp.getRelExps().get(0).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
        IrBr irBr=null;
        if(eqExp.getRelExps().size()==1){
            right=new IrValue(IrValueType.I32,String.valueOf(0));
            irBr=new IrBr(IrInstructionType.Beq,left,right,destLabel);

        }else if(eqExp.getRelExps().size()==2){
            right=eqExp.getRelExps().get(1).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
            if(eqExp.getOps().get(0).equals(Word.EQL)){
                irBr=new IrBr(IrInstructionType.Bne,left,right,destLabel);
            }else {
                irBr=new IrBr(IrInstructionType.Beq,left,right,destLabel);
            }

        }else {
            IrBinaryInstruction tmp=null;
            for(int i=1;i<eqExp.getRelExps().size()-1;i++){
                int cnt=functionCnt.getCnt();
                String name="%_LocalVariable"+cnt;
                right=eqExp.getRelExps().get(i).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
                if(eqExp.getOps().get(i-1).equals(Word.EQL)){
                    tmp=new IrBinaryInstruction(IrValueType.I32,name,IrInstructionType.Eq,left,right);

                }else {
                    tmp=new IrBinaryInstruction(IrValueType.I32,name,IrInstructionType.Ne,left,right);
                }
                left=tmp;
                instructions1.add(tmp);
            }
            right=eqExp.getRelExps().get(eqExp.getRelExps().size()-1).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
            if(eqExp.getOps().get(0).equals(Word.EQL)){
                irBr=new IrBr(IrInstructionType.Bne,left,right,destLabel);
            }else {
                irBr=new IrBr(IrInstructionType.Beq,left,right,destLabel);
            }

        }
//        if(!isLoop){
//            if(size==1){
//                if(eqExp.getRelExps().size()==1){
//                    right=new IrValue(IrValueType.I32,String.valueOf(0));
//                    irBr=new IrBr(IrInstructionType.Bne,left,right,ifLabel);
//
//                }else if(eqExp.getRelExps().size()==2){
//                    right=eqExp.getRelExps().get(1).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
//                    if(eqExp.getOps().get(0).equals(Word.EQL)){
//                        irBr=new IrBr(IrInstructionType.Beq,left,right,ifLabel);
//                    }else {
//                        irBr=new IrBr(IrInstructionType.Bne,left,right,ifLabel);
//                    }
//
//                }else {
//                    IrBinaryInstruction tmp=null;
//                    for(int i=1;i<eqExp.getRelExps().size()-1;i++){
//                        int cnt=functionCnt.getCnt();
//                        String name="%_LocalVariable"+cnt;
//                        right=eqExp.getRelExps().get(i).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
//
//                        if(eqExp.getOps().get(i-1).equals(Word.EQL)){
//                            tmp=new IrBinaryInstruction(IrValueType.I32,name,IrInstructionType.Eq,left,right);
//
//                        }else {
//                            tmp=new IrBinaryInstruction(IrValueType.I32,name,IrInstructionType.Ne,left,right);
//                        }
//                        left=tmp;
//                        instructions1.add(tmp);
//                    }
//                    right=eqExp.getRelExps().get(eqExp.getRelExps().size()-1).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
//                    if(eqExp.getOps().get(0).equals(Word.EQL)){
//                        irBr=new IrBr(IrInstructionType.Beq,left,right,ifLabel);
//                    }else {
//                        irBr=new IrBr(IrInstructionType.Bne,left,right,ifLabel);
//                    }
//
//                }
//            }else {
//                if(eqExp.getRelExps().size()==1){
//                    right=new IrValue(IrValueType.I32,String.valueOf(0));
//                    irBr=new IrBr(IrInstructionType.Beq,left,right,destLabel);
//
//                }else if(eqExp.getRelExps().size()==2){
//                    right=eqExp.getRelExps().get(1).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
//                    if(eqExp.getOps().get(0).equals(Word.EQL)){
//                        irBr=new IrBr(IrInstructionType.Bne,left,right,destLabel);
//                    }else {
//                        irBr=new IrBr(IrInstructionType.Beq,left,right,destLabel);
//                    }
//
//                }else {
//                    IrBinaryInstruction tmp=null;
//                    for(int i=1;i<eqExp.getRelExps().size()-1;i++){
//                        int cnt=functionCnt.getCnt();
//                        String name="%_LocalVariable"+cnt;
//                        right=eqExp.getRelExps().get(i).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
//                        if(eqExp.getOps().get(i-1).equals(Word.EQL)){
//                            tmp=new IrBinaryInstruction(IrValueType.I32,name,IrInstructionType.Eq,left,right);
//
//                        }else {
//                            tmp=new IrBinaryInstruction(IrValueType.I32,name,IrInstructionType.Ne,left,right);
//                        }
//                        left=tmp;
//                        instructions1.add(tmp);
//                    }
//                    right=eqExp.getRelExps().get(eqExp.getRelExps().size()-1).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
//                    if(eqExp.getOps().get(0).equals(Word.EQL)){
//                        irBr=new IrBr(IrInstructionType.Bne,left,right,destLabel);
//                    }else {
//                        irBr=new IrBr(IrInstructionType.Beq,left,right,destLabel);
//                    }
//
//                }
//            }
//        }else {
//            if(eqExp.getRelExps().size()==1){
//                right=new IrValue(IrValueType.I32,String.valueOf(0));
//                irBr=new IrBr(IrInstructionType.Beq,left,right,destLabel);
//
//            }else if(eqExp.getRelExps().size()==2){
//                right=eqExp.getRelExps().get(1).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
//                if(eqExp.getOps().get(0).equals(Word.EQL)){
//                    irBr=new IrBr(IrInstructionType.Bne,left,right,destLabel);
//                }else {
//                    irBr=new IrBr(IrInstructionType.Beq,left,right,destLabel);
//                }
//
//            }else {
//                IrBinaryInstruction tmp=null;
//                for(int i=1;i<eqExp.getRelExps().size()-1;i++){
//                    int cnt=functionCnt.getCnt();
//                    String name="%_LocalVariable"+cnt;
//                    right=eqExp.getRelExps().get(i).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
//                    if(eqExp.getOps().get(i-1).equals(Word.EQL)){
//                        tmp=new IrBinaryInstruction(IrValueType.I32,name,IrInstructionType.Eq,left,right);
//
//                    }else {
//                        tmp=new IrBinaryInstruction(IrValueType.I32,name,IrInstructionType.Ne,left,right);
//                    }
//                    left=tmp;
//                    instructions1.add(tmp);
//                }
//                right=eqExp.getRelExps().get(eqExp.getRelExps().size()-1).generateMidCode(instructions1,linkSymbolTable,functionCnt,false);
//                if(eqExp.getOps().get(0).equals(Word.EQL)){
//                    irBr=new IrBr(IrInstructionType.Bne,left,right,destLabel);
//                }else {
//                    irBr=new IrBr(IrInstructionType.Beq,left,right,destLabel);
//                }
//
//            }
//        }
        irBasicBlock.addAllInstructions(instructions1);
        irBasicBlock.addInstruction(irBr);
        this.basicBlocks.add(irBasicBlock);
    }
    public IrLabel generateIrBasicBlockFromLAndExp(LAndExp lAndExp,IrLabel ifLabel,IrLabel destLabel,boolean isLoop){
        IrLabel irLabel=null;
        int cnt=IrLabelCnt.getInstance().getCnt();
        String name="%Label"+cnt;
        irLabel=new IrLabel(name);
        for(EqExp eqExp:lAndExp.getEqExps()){

            generateBasicBlockFromEqExp(eqExp,ifLabel,lAndExp.getEqExps().size(),irLabel,isLoop);

        }


        IrGoto irGoto=new IrGoto(ifLabel);
        IrBasicBlock irBasicBlock=new IrBasicBlock();
        irBasicBlock.setName("GOTO-IF");
        irBasicBlock.addInstruction(irGoto);
        this.basicBlocks.add(irBasicBlock);
        return irLabel;
    }
    public void generateBasicBlockFromLorExp(IrLabel destLabel,IrLabel ifLabel,LOrExp lOrExp,boolean isLoop){


        for(LAndExp lAndExp:lOrExp.getlAndExps()){

            //不满足就继续继续判断下一个,满足则跳if
            IrLabel irLabel=generateIrBasicBlockFromLAndExp(lAndExp,ifLabel,destLabel,isLoop);
            if(irLabel!=null){
                IrBasicBlock irBasicBlock=new IrBasicBlock();
                irBasicBlock.setName("NEXT-LANDLABEL");
                irBasicBlock.addInstruction(irLabel);
                this.basicBlocks.add(irBasicBlock);
            }
        }

        IrBasicBlock irBasicBlock=new IrBasicBlock();
        IrGoto irGoto=new IrGoto(destLabel);
        irBasicBlock.addInstruction(irGoto);
        this.basicBlocks.add(irBasicBlock);

    }
    public ArrayList<IrBasicBlock> generateIrBasicBlockFromIfStmt(){

        //If-BLock

        int cnt= IrLabelCnt.getInstance().getCnt();
        String name="%Label"+cnt;
        IrLabel ifBlockLabel=new IrLabel(name);

        //Else-Block
        IrLabel elseBlockLabel=null;
        if(ifStmt.getElseStmt()!=null){
            cnt=IrLabelCnt.getInstance().getCnt();
            String name1="%Label"+cnt;
            elseBlockLabel=new IrLabel(name1);
        }

        //End-Label
        cnt=IrLabelCnt.getInstance().getCnt();
        String name2="%Label"+cnt;
        IrLabel endLabel=new IrLabel(name2);

        //处理Cond语句块


        if(elseBlockLabel!=null){
            generateBasicBlockFromLorExp(elseBlockLabel,ifBlockLabel,ifStmt.getCond().getlOrExp(),false);
        }else {
            generateBasicBlockFromLorExp(endLabel,ifBlockLabel,ifStmt.getCond().getlOrExp(),false);
        }

        //IrGoto irGoto=new IrGoto(endLabel);



        //TODO：有个问题呀，我不觉得有必要添加goto语句
        //处理if语句块
        IrBasicBlock ifBlock=new IrBasicBlock();
        ifBlock.setName("IF-BLOCK");
        ifBlock.addInstruction(ifBlockLabel);

        Stmt thenStmt=ifStmt.getThenStmt();
        LinkSymbolTable newLinkSymbolTable=new LinkSymbolTable(linkSymbolTable);

        if(thenStmt instanceof BlockStmt){
            this.basicBlocks.add(ifBlock);
            IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(newLinkSymbolTable,((BlockStmt)thenStmt).getBlock(),functionCnt,nextStepForLoop,endLabelForLoop);
            this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());
            IrGoto irGoto=new IrGoto(endLabel);
            IrBasicBlock irBasicBlock=new IrBasicBlock();
            irBasicBlock.addInstruction(irGoto);
            this.basicBlocks.add(irBasicBlock);
        }else if(thenStmt instanceof IfStmt){
            this.basicBlocks.add(ifBlock);
            IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(newLinkSymbolTable,(IfStmt) thenStmt,functionCnt,nextStepForLoop,endLabelForLoop);
            this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());
            IrGoto irGoto=new IrGoto(endLabel);
            IrBasicBlock irBasicBlock=new IrBasicBlock();
            irBasicBlock.addInstruction(irGoto);
            this.basicBlocks.add(irBasicBlock);
        }else if(thenStmt instanceof ForLoopStmt){
            this.basicBlocks.add(ifBlock);
            IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(newLinkSymbolTable,(ForLoopStmt) thenStmt,functionCnt);
            this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());
            IrGoto irGoto=new IrGoto(endLabel);
            IrBasicBlock irBasicBlock=new IrBasicBlock();
            irBasicBlock.addInstruction(irGoto);
            this.basicBlocks.add(irBasicBlock);
        }else {

            IrInstructionGenerator irInstructionBuilder = new IrInstructionGenerator(
                    linkSymbolTable, thenStmt,this.functionCnt, nextStepForLoop,endLabelForLoop);
            ArrayList<IrInstruction> instructions = irInstructionBuilder.generateIrInstructions();
            if (instructions != null) {
                ifBlock.addAllInstructions(instructions);
            }
            IrGoto irGoto=new IrGoto(endLabel);
            ifBlock.addInstruction(irGoto);
            this.basicBlocks.add(ifBlock);


        }

        //处理else
        if(elseBlockLabel!=null){
            IrBasicBlock elseBlock=new IrBasicBlock();
            elseBlock.setName("ELSE-BLOCK");
            elseBlock.addInstruction(elseBlockLabel);

            Stmt elseStmt=ifStmt.getElseStmt();
            LinkSymbolTable newLinkSymbolTable1=new LinkSymbolTable(linkSymbolTable);
            if(elseStmt instanceof BlockStmt){
                this.basicBlocks.add(elseBlock);
                IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(newLinkSymbolTable1,((BlockStmt)elseStmt).getBlock(),functionCnt,nextStepForLoop,endLabelForLoop);
                this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());
                //不用加入goto语句，因为else结束顺序到结束
            }else if(elseStmt instanceof IfStmt){
                this.basicBlocks.add(elseBlock);
                IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(newLinkSymbolTable1,(IfStmt) elseStmt,functionCnt,nextStepForLoop,endLabelForLoop);
                this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());


            }else if(elseStmt instanceof ForLoopStmt){
                this.basicBlocks.add(elseBlock);
                IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(newLinkSymbolTable1,(ForLoopStmt) elseStmt,functionCnt);
                this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());

            }else {
                IrInstructionGenerator irInstructionBuilder = new IrInstructionGenerator(
                        linkSymbolTable, elseStmt, this.functionCnt,nextStepForLoop,endLabelForLoop);
                ArrayList<IrInstruction> instructions = irInstructionBuilder.generateIrInstructions();
                if (instructions != null) {
                    elseBlock.addAllInstructions(instructions);
                }
                this.basicBlocks.add(elseBlock);
            }
        }
        IrBasicBlock irBasicBlock=new IrBasicBlock();
        irBasicBlock.setName("END-LABEL");
        irBasicBlock.addInstruction(endLabel);
        this.basicBlocks.add(irBasicBlock);
        return this.basicBlocks;



    }
    public ArrayList<IrBasicBlock> generateIrBasicBlockFromForLoopStmt(){

        //cond-label
        int cnt=IrLabelCnt.getInstance().getCnt();
        String name="%Label"+cnt;
        IrLabel condLabel=new IrLabel(name);

        //if-block-label
        cnt=IrLabelCnt.getInstance().getCnt();
        name="%Label"+cnt;
        IrLabel ifBlockLabel=new IrLabel(name);

        IrLabel updateLabel=null;
        if(forLoopStmt.getUpdateStmt()!=null){
            cnt=IrLabelCnt.getInstance().getCnt();
            name="%Label"+cnt;
            updateLabel=new IrLabel(name);

        }

        //end-label
        cnt=IrLabelCnt.getInstance().getCnt();
        name="%Label"+cnt;
        IrLabel endLabel=new IrLabel(name);
        endLabelForLoop=endLabel;

        if(updateLabel!=null){
            nextStepForLoop=updateLabel;
        }else {
            nextStepForLoop=condLabel;
        }
        //初始化
        if(forLoopStmt.getInitStmt()!=null){
            IrBasicBlock initBlock=new IrBasicBlock();
            ArrayList<IrInstruction> instructions=new ArrayList<>();
            LVal lVal=forLoopStmt.getInitStmt().getlVal();
            Exp exp=forLoopStmt.getInitStmt().getExp();
            IrValue storeValue=exp.generateMidCode(instructions,linkSymbolTable,functionCnt,false);
            IrValue storeAddress=lVal.generateMidCode(instructions,linkSymbolTable,functionCnt,true);
            IrValue offset=storeAddress.getDimensionIndex();
            IrStore irStore=new IrStore(storeValue,storeAddress,offset);
            instructions.add(irStore);
            initBlock.addAllInstructions(instructions);
            this.basicBlocks.add(initBlock);
        }


        IrBasicBlock condBlock=new IrBasicBlock();
        condBlock.setName("Cond-Block");
        condBlock.addInstruction(condLabel);
        this.basicBlocks.add(condBlock);
        //cond处理
        if(forLoopStmt.getLoopCond()!=null){
            generateBasicBlockFromLorExp(endLabel,ifBlockLabel,forLoopStmt.getLoopCond().getlOrExp(),true);
        }

        //if-block处理
        IrBasicBlock ifBlock=new IrBasicBlock();
        ifBlock.setName("For-If-Block");
        ifBlock.addInstruction(ifBlockLabel);

        Stmt loopStmt=forLoopStmt.getLoopStmt();
        LinkSymbolTable linkSymbolTable1=new LinkSymbolTable(linkSymbolTable);
        if(loopStmt instanceof BlockStmt){
            this.basicBlocks.add(ifBlock);
            IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(linkSymbolTable1,((BlockStmt)loopStmt).getBlock(),functionCnt,nextStepForLoop,endLabelForLoop);
            this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());

        }else if(loopStmt instanceof IfStmt){
            this.basicBlocks.add(ifBlock);
            IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(linkSymbolTable1,((IfStmt)loopStmt),functionCnt,nextStepForLoop,endLabelForLoop);
            this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());
        }else if(loopStmt instanceof ForLoopStmt){
            this.basicBlocks.add(ifBlock);
            IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(linkSymbolTable1,((ForLoopStmt)loopStmt),functionCnt);
            this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());
        }else {

            IrInstructionGenerator irInstructionBuilder = new IrInstructionGenerator(
                    linkSymbolTable, loopStmt, this.functionCnt,nextStepForLoop,endLabel);
            ArrayList<IrInstruction> instructions = irInstructionBuilder.generateIrInstructions();
            if (instructions != null) {
                ifBlock.addAllInstructions(instructions);
            }
            this.basicBlocks.add(ifBlock);
        }


        //update-block
        if(forLoopStmt.getUpdateStmt()!=null){
            IrBasicBlock updateBlock=new IrBasicBlock();
            updateBlock.setName("Update-Block");
            updateBlock.addInstruction(updateLabel);
            ArrayList<IrInstruction> instructions=new ArrayList<>();
            LVal lVal=forLoopStmt.getUpdateStmt().getlVal();
            Exp exp=forLoopStmt.getUpdateStmt().getExp();
            IrValue storeValue=exp.generateMidCode(instructions,linkSymbolTable,functionCnt,false);
            IrValue storeAddress=lVal.generateMidCode(instructions,linkSymbolTable,functionCnt,true);
            IrValue offset=storeAddress.getDimensionIndex();
            IrStore irStore=new IrStore(storeValue,storeAddress,offset);
            instructions.add(irStore);
            updateBlock.addAllInstructions(instructions);
            this.basicBlocks.add(updateBlock);
        }

        IrBasicBlock gotoBlock=new IrBasicBlock();
        gotoBlock.setName("Goto-Block");
        IrGoto irGoto=new IrGoto(condLabel);
        gotoBlock.addInstruction(irGoto);
        this.basicBlocks.add(gotoBlock);


        //加入end-label
        IrBasicBlock endBlock=new IrBasicBlock();
        endBlock.setName("End-Block");
        endBlock.addInstruction(endLabel);
        this.basicBlocks.add(endBlock);


        return this.basicBlocks;
    }
    public ArrayList<IrBasicBlock> generateIrBasicBlockFromBlock() {

        for (BlockItem item : this.blockItems) {
            LinkSymbolTable newLinkSymbolTable=new LinkSymbolTable(this.linkSymbolTable);
            if(item instanceof ForLoopStmt){
                IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(newLinkSymbolTable,((ForLoopStmt)(item)),functionCnt);
                this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());
            }else if(item instanceof IfStmt){
                IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(newLinkSymbolTable,((IfStmt)(item)),functionCnt,nextStepForLoop,endLabelForLoop);
                this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());
            }else if(item instanceof BlockStmt){
                IrBasicBlockGenerator irBasicBlockGenerator=new IrBasicBlockGenerator(newLinkSymbolTable,((BlockStmt)item).getBlock(),functionCnt,nextStepForLoop,endLabelForLoop);
                this.basicBlocks.addAll(irBasicBlockGenerator.generateIrBasicBlock());

            }else {
                IrBasicBlock basicBlock = new IrBasicBlock();
                IrInstructionGenerator irInstructionBuilder = new IrInstructionGenerator(
                        linkSymbolTable, item, this.functionCnt,nextStepForLoop,endLabelForLoop);
                ArrayList<IrInstruction> instructions = irInstructionBuilder.generateIrInstructions();
                if (instructions != null) {
                    basicBlock.addAllInstructions(instructions);
                }
                this.basicBlocks.add(basicBlock);
            }

        }


        return this.basicBlocks;
    }
}
