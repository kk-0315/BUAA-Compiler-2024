package midend.value.basicBlock;

import midend.IrUser;
import midend.IrValue;
import midend.type.IrValueType;
import midend.value.instructions.IrInstruction;

import java.util.ArrayList;

public class IrBasicBlock extends IrValue {
    private ArrayList<IrInstruction> instructions;
    public IrBasicBlock() {
        super(IrValueType.LABEL);
        this.instructions=new ArrayList<>();
    }
    public ArrayList<IrInstruction> getInstructions(){
        return instructions;
    }
    public void addAllInstructions(ArrayList<IrInstruction> instructions){
        this.instructions.addAll(instructions);
    }
    public void addInstruction(IrInstruction irInstruction){
        instructions.add(irInstruction);
    }
    public String toString(){
        StringBuilder sb=new StringBuilder();
        for(IrInstruction irInstruction:instructions){
            sb.append(irInstruction.toString());
        }
        return sb.toString();
    }
}
