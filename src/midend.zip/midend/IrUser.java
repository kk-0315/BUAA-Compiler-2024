package midend;

import midend.type.IrValueType;

import java.util.ArrayList;

public class IrUser extends IrValue{
    private int opNum;
    private ArrayList<IrUse> irUses;

    public IrUser(IrValueType irValueType, String name,int opNum) {
        super(irValueType, name);
        this.opNum=opNum;
        this.irUses=new ArrayList<>();
    }
    public IrUser(IrValueType irValueType, String name){
        super(irValueType,name);
        this.irUses=new ArrayList<>();
    }
    public IrUser(IrValueType irValueType){
        super(irValueType);
        this.irUses=new ArrayList<>();
    }
    public IrUser(IrValueType irValueType,int opNum){
        super(irValueType);
        this.irUses=new ArrayList<>();
        this.opNum=opNum;
    }
    public int getOpNum(){
        return opNum;
    }
    public void setIrUses(IrValue irValue,int index){
        for(IrUse irUse:irUses){
            if(irUse.getOperandRank()==index){
                irUse.getIrValue().removeIrUse(irUse);
                irUse.setIrValue(irValue);
                irValue.addIrUse(irUse);
                return;
            }
        }
        IrUse irUse=new IrUse(index,this,irValue);
        irUses.add(irUse);
    }
    public IrValue getOperand1(){
        if(!irUses.isEmpty()){
            return irUses.get(0).getIrValue();
        }
        return null;
    }
    public IrValue getOperand2(){
        if(irUses.size()>1){
            return irUses.get(1).getIrValue();
        }
        return null;
    }
    public IrValue getOperandFromIndex(int index){
        for(IrUse irUse:irUses){
            if(irUse.getOperandRank()==index){
                return irUse.getIrValue();
            }
        }
        return null;
    }
    public ArrayList<IrValue> getOperands(){
        ArrayList<IrValue> irValues=new ArrayList<>();
        for(IrUse irUse:irUses){
            irValues.add(irUse.getIrValue());
        }
        return irValues;
    }
}
