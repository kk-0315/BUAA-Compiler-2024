package backend.instructions;

import backend.RegTable;
import backend.basicblocks.MipsBasicBlock;
import backend.symbols.MipsSymbol;
import backend.symbols.MipsSymbolTable;
import midend.IrValue;
import midend.type.IrValueType;
import midend.value.instructions.*;
import midend.value.instructions.memory.IrAlloc;
import midend.value.instructions.memory.IrLoad;
import midend.value.instructions.memory.IrStore;
import midend.value.instructions.terminal.IrBr;
import midend.value.instructions.terminal.IrCall;
import midend.value.instructions.terminal.IrGoto;
import midend.value.instructions.terminal.IrRet;

import java.util.ArrayList;

public class MipsInstructionGenerator {
    private IrInstruction irInstruction;
    private MipsSymbolTable mipsSymbolTable; //指令所在符号表
    private MipsBasicBlock parentBasicBlock; //父基本块
    private ArrayList<MipsInstruction> mipsInstructions;

    public MipsInstructionGenerator(IrInstruction irInstruction, MipsSymbolTable mipsSymbolTable, MipsBasicBlock parentBasicBlock) {
        this.irInstruction = irInstruction;
        this.mipsSymbolTable = mipsSymbolTable;
        this.parentBasicBlock = parentBasicBlock;
        this.mipsInstructions = new ArrayList<>();
    }

    public ArrayList<MipsInstruction> generateMipsInstruction() {
        if (irInstruction instanceof IrRet) {
            generateMipsInstructionFromIrRet();
        } else if (irInstruction instanceof IrAlloc) {
            generateMipsInstructionFromIrAlloc();
        } else if (irInstruction instanceof IrLoad) {
            generateMipsInstructionFromIrLoad();
        } else if (irInstruction instanceof IrStore) {
            generateMipsInstructionFromIrStore();
        } else if (irInstruction instanceof IrCall) {
            generateMipsInstructionFromIrCall();
        }else if(irInstruction instanceof IrBinaryInstruction){
            generateMipsInstructionFromIrBinaryInstruction();
        }else if(irInstruction instanceof IrGoto){
            generateMipsInstructionFromIrGoto();
        }else if(irInstruction instanceof IrBr){
            generateMipsInstructionFromIrBr();
        }else if(irInstruction instanceof IrLabel){
            generateMipsInstructionFromIrLabel();
        }
        //TODO:更多的指令
        return mipsInstructions;
    }
    public void generateMipsInstructionFromIrLabel(){
        IrLabel irLabel=((IrLabel) irInstruction);
        mipsInstructions.add(new Label(irLabel.getName().substring(1)));
    }
    public void calculateBr(String gotoLabel,IrInstructionType irInstructionType,int op1Reg,int op2Reg){
        if(irInstructionType.equals(IrInstructionType.Beq)){
            mipsInstructions.add(new Beq(op1Reg,op2Reg,gotoLabel));
        }else {
            mipsInstructions.add(new Bne(op1Reg,op2Reg,gotoLabel));
        }
    }
    public void generateMipsInstructionFromIrBr(){
        IrBr irBr=((IrBr) irInstruction);
        IrInstructionType irInstructionType=irBr.getIrInstructionType();
        IrValue op1=irBr.getOperand1();
        IrValue op2=irBr.getOperand2();

        MipsSymbol op1Symbol=null;
        MipsSymbol op2Symbol=null;
        int op1Reg=-1;
        int op2Reg=-1;

        if(isConst(op1.getName())){
            if(isConst(op2.getName())){
                op1Symbol=new MipsSymbol("tmpOp1",true);
                op2Symbol=new MipsSymbol("tmpOp2",true);
                op1Reg=mipsSymbolTable.getRegTable().distributeRegForSymbol(op1Symbol,mipsInstructions);
                op2Reg=mipsSymbolTable.getRegTable().distributeRegForSymbol(op2Symbol,mipsInstructions);
                mipsInstructions.add(new Li(op1Reg,Integer.parseInt(op1.getName())));
                mipsInstructions.add(new Li(op2Reg,Integer.parseInt(op2.getName())));
                //均为常数

            }else {
                //op1为常数，op2不为
                op1Symbol=new MipsSymbol("tmpOp1",true);
                op1Reg=mipsSymbolTable.getRegTable().distributeRegForSymbol(op1Symbol,mipsInstructions);
                op2Reg=mipsSymbolTable.getRegIndex(op2.getName(),mipsInstructions);
                mipsInstructions.add(new Li(op1Reg,Integer.parseInt(op1.getName())));

            }
        }else {
            if(isConst(op2.getName())){
                //op1不为常数，op2为
                op1Reg=mipsSymbolTable.getRegIndex(op1.getName(),mipsInstructions);
                op2Symbol=new MipsSymbol("tmpOp2",true);
                op2Reg=mipsSymbolTable.getRegTable().distributeRegForSymbol(op2Symbol,mipsInstructions);
                mipsInstructions.add(new Li(op2Reg,Integer.parseInt(op2.getName())));
            }else {
                //均不为常数
                op1Reg=mipsSymbolTable.getRegIndex(op1.getName(),mipsInstructions);
                op2Reg=mipsSymbolTable.getRegIndex(op2.getName(), mipsInstructions);
            }
        }
        calculateBr(irBr.getOperandFromIndex(2).getName().substring(1),irInstructionType,op1Reg,op2Reg);

        if(op1Reg!=-1){
            mipsSymbolTable.getRegTable().setUsed(op1Reg);
        }
        if(op2Reg!=-1){
            mipsSymbolTable.getRegTable().setUsed(op2Reg);
        }
    }
    public void generateMipsInstructionFromIrGoto(){
        IrGoto irGoto=((IrGoto) irInstruction);
        IrLabel irLabel= (IrLabel) irGoto.getOperand1();
        mipsInstructions.add(new J(irLabel.getName().substring(1)));
    }
    public void calculateBinary(int destReg,IrInstructionType irInstructionType,int op1Reg,int op2Reg){
        switch (irInstructionType){
            case ADD:
                mipsInstructions.add(new Add(destReg,op1Reg,op2Reg));
                break;
            case SUB:
                mipsInstructions.add(new Sub(destReg,op1Reg,op2Reg));
                break;
            case DIV:
                mipsInstructions.add(new Div(destReg,op1Reg,op2Reg));
                break;
            case MUL:
                mipsInstructions.add(new Mul(destReg,op1Reg,op2Reg));
                break;
            case MOD:
                mipsInstructions.add(new Div(-1,op1Reg,op2Reg));
                mipsInstructions.add(new Mfhi(destReg));
                break;
            case Lt:
                mipsInstructions.add(new Slt(destReg,op1Reg,op2Reg));
                break;
            case Le:
                mipsInstructions.add(new Sle(destReg,op1Reg,op2Reg));
                break;
            case Gt:
                mipsInstructions.add(new Sgt(destReg,op1Reg,op2Reg));
                break;
            case Ge:
                mipsInstructions.add(new Sge(destReg,op1Reg,op2Reg));
                break;
            case Eq:
                mipsInstructions.add(new Seq(destReg,op1Reg,op2Reg));
                break;
            case Ne:
                mipsInstructions.add(new Sne(destReg,op1Reg,op2Reg));
                break;
            case Not:

        }
    }
    public void generateMipsInstructionFromIrBinaryInstruction(){
        IrBinaryInstruction irBinaryInstruction=((IrBinaryInstruction) irInstruction);
        IrValue op1=irBinaryInstruction.getOperand1();
        IrValue op2=irBinaryInstruction.getOperand2(); //NOT的时候为空
        MipsSymbol left=new MipsSymbol(irBinaryInstruction.getName(),true);
        mipsSymbolTable.addSymbol(left.getName(),left);
        int leftReg=mipsSymbolTable.getRegTable().distributeRegForSymbol(left,mipsInstructions);//分配临时寄存器
        IrInstructionType irInstructionType=irBinaryInstruction.getIrInstructionType();
        MipsSymbol op1Symbol=null;
        MipsSymbol op2Symbol=null;
        int op1Reg=-1;
        int op2Reg=-1;
        if(op2==null){
            if(isConst(op1.getName())){
                op1Symbol=new MipsSymbol("tmpOp1",true);
                op1Reg=mipsSymbolTable.getRegTable().distributeRegForSymbol(op1Symbol,mipsInstructions);
                mipsInstructions.add(new Li(op1Reg,Integer.parseInt(op1.getName())));
            }else {
                op1Reg=mipsSymbolTable.getRegIndex(op1.getName(),mipsInstructions);
            }

            mipsInstructions.add(new Li(3,0));
            mipsInstructions.add(new Seq(leftReg,op1Reg,3));
        }else {

            if(isConst(op1.getName())){
                if(isConst(op2.getName())){
                    op1Symbol=new MipsSymbol("tmpOp1",true);
                    op2Symbol=new MipsSymbol("tmpOp2",true);
                    op1Reg=mipsSymbolTable.getRegTable().distributeRegForSymbol(op1Symbol,mipsInstructions);
                    op2Reg=mipsSymbolTable.getRegTable().distributeRegForSymbol(op2Symbol,mipsInstructions);
                    mipsInstructions.add(new Li(op1Reg,Integer.parseInt(op1.getName())));
                    mipsInstructions.add(new Li(op2Reg,Integer.parseInt(op2.getName())));
                    //均为常数

                }else {
                    //op1为常数，op2不为
                    op1Symbol=new MipsSymbol("tmpOp1",true);
                    op1Reg=mipsSymbolTable.getRegTable().distributeRegForSymbol(op1Symbol,mipsInstructions);
                    op2Reg=mipsSymbolTable.getRegIndex(op2.getName(),mipsInstructions);
                    mipsInstructions.add(new Li(op1Reg,Integer.parseInt(op1.getName())));

                }
            }else {
                if(isConst(op2.getName())){
                    //op1不为常数，op2为
                    op1Reg=mipsSymbolTable.getRegIndex(op1.getName(),mipsInstructions);
                    op2Symbol=new MipsSymbol("tmpOp2",true);
                    op2Reg=mipsSymbolTable.getRegTable().distributeRegForSymbol(op2Symbol,mipsInstructions);
                    mipsInstructions.add(new Li(op2Reg,Integer.parseInt(op2.getName())));
                }else {
                    //均不为常数
                    op1Reg=mipsSymbolTable.getRegIndex(op1.getName(),mipsInstructions);
                    op2Reg=mipsSymbolTable.getRegIndex(op2.getName(), mipsInstructions);
                }
            }
            calculateBinary(leftReg,irInstructionType,op1Reg,op2Reg);
        }
        if(op1Reg!=-1){
            mipsSymbolTable.getRegTable().setUsed(op1Reg);
        }
        if(op2Reg!=-1){
            mipsSymbolTable.getRegTable().setUsed(op2Reg);
        }


    }
    public void generateMipsInstructionFromIrCall() {
        IrCall irCall = ((IrCall) irInstruction);

        if (irCall.getFunctionName().equals("@putint") || irCall.getFunctionName().equals("@putchar")) {
            IrValue printValue = irCall.getOperandFromIndex(1);
            MipsSymbol mipsSymbol = mipsSymbolTable.getMipsSymbol(printValue.getName());
            if (isConst(printValue.getName())) {
                mipsInstructions.add(new Li(4, Integer.parseInt(printValue.getName())));
            } else {
                int reg = mipsSymbolTable.getRegIndex(printValue.getName(), mipsInstructions); //肯定已经load出来了
                mipsInstructions.add(new Move(4, reg));

                if(reg!=-1){
                    mipsSymbolTable.getRegTable().setUsed(reg);
                }
            }

            if (irCall.getFunctionName().equals("@putint")) {
                mipsInstructions.add(new Li(2, 1));
                mipsInstructions.add(new Syscall());
            } else {
                mipsInstructions.add(new Li(2, 11));
                mipsInstructions.add(new Syscall());
            }
        } else if (irCall.getFunctionName().equals("@getint") || irCall.getFunctionName().equals("@getchar")) {
            String varName = irCall.getName();
            MipsSymbol mipsSymbol = new MipsSymbol(varName, true); //创建临时变量
            mipsSymbolTable.addSymbol(mipsSymbol.getName(), mipsSymbol);
            int leftReg = -1;

            leftReg = mipsSymbolTable.getRegTable().distributeRegForSymbol(mipsSymbol, mipsInstructions);
            Li li = null;
            if (irCall.getFunctionName().equals("@getint")) {
                li = new Li(2, 5);

            } else {
                li = new Li(2, 12);
            }
            mipsInstructions.add(li);
            mipsInstructions.add(new Syscall());
            mipsInstructions.add(new Move(leftReg, 2));
        } else {
            ArrayList<IrValue> irParams = irCall.getrParams();
            int newSpOffset = 0;

            ArrayList<MipsInstruction> tmpInst1=new ArrayList<>();
            for (int i = 0; i < irParams.size(); i++) {
                IrValue param = irParams.get(i);
                if (mipsSymbolTable.hasSymbol(param.getName())) {
                    MipsSymbol paramSymbol = mipsSymbolTable.getMipsSymbol(param.getName());
                    int paramReg=mipsSymbolTable.getRegIndex(paramSymbol.getName(),mipsInstructions); //临时寄存器，肯定已经load到了
                    if (i < 4) {
                        mipsInstructions.add(new Move(4 + i, paramReg)); //直接传递
                    } else {
                        tmpInst1.add(new Sw(paramReg, 29, newSpOffset));
                    }
                    if(paramReg!=-1){
                        mipsSymbolTable.getRegTable().setUsed(paramReg);
                    }
                } else { //常数参数
                    if (i < 4) {
                        mipsInstructions.add(new Li(i + 4, Integer.parseInt(param.getName())));
                    } else {
                        MipsSymbol tmp = new MipsSymbol("tmp", true);
                        int tmpReg = mipsSymbolTable.getRegTable().distributeRegForSymbol(tmp, mipsInstructions);
                        tmpInst1.add(new Li(tmpReg, Integer.parseInt(param.getName())));
                        tmpInst1.add(new Sw(tmpReg, 29, newSpOffset));
                        if(tmpReg!=-1){
                            mipsSymbolTable.getRegTable().setUsed(tmpReg);
                        }
                    }
                }
                if (i >= 4) {
                    newSpOffset += 4;
                }
            }


            //2.将所有有值的寄存器保存到$sp上,保存现场
            ArrayList<MipsInstruction> tmpInst=new ArrayList<>();
            int spOffset = 0;
            for (int i = 2; i < 32; i++) {
                if (26 <= i && i <= 30) {
                    continue;
                }
                if (mipsSymbolTable.getRegTable().needSave(i) || i == 31) {
                    tmpInst.add(new Sw(i, 29, spOffset));
                    spOffset += 4;
                }
            }
            tmpInst.add(new Sw(30,29,spOffset));
            spOffset+=4;
            mipsInstructions.add(new Addi(29,29,-1*spOffset));
            mipsInstructions.addAll(tmpInst);
            if(!tmpInst1.isEmpty()){
                mipsInstructions.add(new Addi(29,29,-1*newSpOffset));
                mipsInstructions.addAll(tmpInst1);
            }
            mipsInstructions.add(new Addi(30,30,mipsSymbolTable.getFpOffset()));


            //7.函数调用
            mipsInstructions.add(new Jal(irCall.getFunctionName().substring(1)));

            //8.恢复现场


            int retSpOffSet=spOffset; //copy一份，用于恢复sp

            spOffset-=4;
            mipsInstructions.add(new Lw(30,29,spOffset+newSpOffset));

            for (int i = 31; i >= 2; i--) {
                if (26 <= i && i <= 30) {
                    continue;
                }
                if ((mipsSymbolTable.getRegTable().needSave(i)|| i == 31)) {
                    spOffset -= 4;
                    mipsInstructions.add(new Lw(i, 29, spOffset+newSpOffset));
                }
            }

            mipsInstructions.add(new Addi(29, 29, retSpOffSet+newSpOffset));

            //9.处理返回值
            if (!irCall.getIrValueType().equals(IrValueType.VOID)) {
                MipsSymbol leftSymbol = new MipsSymbol(irCall.getName(), true);
                mipsSymbolTable.addSymbol(leftSymbol.getName(), leftSymbol);
                int leftReg = mipsSymbolTable.getRegTable().distributeRegForSymbol(leftSymbol,mipsInstructions);//为返回值分配虚拟寄存器
                mipsInstructions.add(new Move(leftReg, 2));
            }
        }
    }

    public void generateMipsInstructionFromIrStore() {
        IrStore irStore = ((IrStore) irInstruction);
        IrValue storeValue = irStore.getStoreValue();
        IrValue storeAddress = irStore.getStoreAddress();
        IrValue offset = irStore.getOffset();
        int leftReg = -1, rightReg = -1;
        MipsSymbol tmp = null;
        //将要存的值取到leftReg里
        if (isConst(storeValue.getName())) {
            tmp = new MipsSymbol("tmp", true); //创建临时变量
            leftReg = mipsSymbolTable.getRegTable().distributeRegForSymbol(tmp, mipsInstructions); //分配临时寄存器
            mipsInstructions.add(new Li(leftReg, Integer.parseInt(storeValue.getName())));
        } else {
            leftReg = mipsSymbolTable.getRegIndex(storeValue.getName(), mipsInstructions);
        }
        if (storeValue.getIrValueType() == IrValueType.I32 && (storeAddress.getIrValueType() == IrValueType.I8||storeAddress.getIrValueType()==IrValueType.I8_ARR)) {
            mipsInstructions.add(new Andi(leftReg, leftReg, 0xFF));// 截断高位，保留最低 8 位
        }
        //开始写回
        MipsSymbol rightSymbol = mipsSymbolTable.getMipsSymbol(storeAddress.getName());

        if (offset == null) {
            mipsInstructions.add(new Sw(leftReg,rightSymbol.getBase(),rightSymbol.getOffset()));

        } else {
            int offsetReg = -1;
            MipsSymbol temp = null;
            temp = new MipsSymbol("temp", true); //创建临时变量

            if (isConst(offset.getName())) {
                offsetReg = mipsSymbolTable.getRegTable().distributeRegForSymbol(temp, mipsInstructions); //分配临时寄存器
                mipsInstructions.add(new Li(offsetReg, Integer.parseInt(offset.getName())));
            } else {
                //中间代码中这个不会load出来，所以在这load
                offsetReg=mipsSymbolTable.getRegIndex(offset.getName(),mipsInstructions);

            }
            mipsInstructions.add(new Sll(3, offsetReg, 2));

            if(offsetReg!=-1){
                mipsSymbolTable.getRegTable().setUsed(offsetReg); //释放临时寄存器
            }
            if(rightSymbol.isParam()){
                MipsSymbol tmp1=new MipsSymbol("tmp",true);
                int tmpReg=mipsSymbolTable.getRegTable().distributeRegForSymbol(tmp1,mipsInstructions);
                mipsInstructions.add(new Addi(tmpReg, rightSymbol.getBase(), rightSymbol.getOffset()));
                mipsInstructions.add(new Lw(tmpReg,tmpReg,0));
                mipsInstructions.add(new Add(3,3,tmpReg));
                if(tmpReg!=-1){
                    mipsSymbolTable.getRegTable().setUsed(tmpReg);
                }
            }else {
                mipsInstructions.add(new Add(3, 3, rightSymbol.getBase()));
                mipsInstructions.add(new Addi(3, 3, rightSymbol.getOffset()));
            }
            mipsInstructions.add(new Sw(leftReg, 3, 0));
        }

        if(leftReg!=-1){
            mipsSymbolTable.getRegTable().setUsed(leftReg); //释放临时寄存器
        }


    }

    public boolean isConst(String name) {
        if (name.startsWith("@") || name.startsWith("%")) {
            return false;
        }
        return true;
    }

    public void generateMipsInstructionFromIrLoad() {
        IrLoad irLoad = ((IrLoad) irInstruction);
        MipsSymbol leftSymbol = new MipsSymbol(irLoad.getName(),true); //临时变量
        mipsSymbolTable.addSymbol(leftSymbol.getName(), leftSymbol);
        IrValue value = irLoad.getOperandFromIndex(0);
        MipsSymbol rightSymbol = mipsSymbolTable.getMipsSymbol(value.getName());
        int leftReg = mipsSymbolTable.getRegTable().distributeRegForSymbol(leftSymbol, mipsInstructions); //为临时变量分配寄存器

        if (irLoad.getOffset() == null) {
            if (rightSymbol.getDimensionNum()!=0) {
                mipsInstructions.add(new Addi(leftReg, rightSymbol.getBase(), rightSymbol.getOffset()));
            } else {
                mipsInstructions.add(new Lw(leftReg,rightSymbol.getBase(),rightSymbol.getOffset()));
            }

        } else {
            int offsetReg = -1;
            IrValue offset = irLoad.getOffset();
            MipsSymbol temp = new MipsSymbol("temp", true); //创建临时变量
            if (isConst(offset.getName())) {

                offsetReg = mipsSymbolTable.getRegTable().distributeRegForSymbol(temp, mipsInstructions);
                Li li = new Li(offsetReg, Integer.parseInt(offset.getName()));
                mipsInstructions.add(li);
            } else {
                offsetReg=mipsSymbolTable.getRegIndex(offset.getName(),mipsInstructions);
            }

            mipsInstructions.add(new Sll(3, offsetReg, 2));

            if(offsetReg!=-1){
                mipsSymbolTable.getRegTable().setUsed(offsetReg);
            }
            if(rightSymbol.isParam()){
                MipsSymbol tmp=new MipsSymbol("tmp",true);
                int tmpReg=mipsSymbolTable.getRegTable().distributeRegForSymbol(tmp,mipsInstructions);
                mipsInstructions.add(new Addi(tmpReg, rightSymbol.getBase(), rightSymbol.getOffset()));
                mipsInstructions.add(new Lw(tmpReg,tmpReg,0));
                mipsInstructions.add(new Add(3,3,tmpReg));
                if(tmpReg!=-1){
                    mipsSymbolTable.getRegTable().setUsed(tmpReg);
                }
            }else {
                mipsInstructions.add(new Add(3, 3, rightSymbol.getBase()));
                mipsInstructions.add(new Addi(3, 3, rightSymbol.getOffset()));
            }



            mipsInstructions.add(new Lw(leftReg, 3, 0));
        }


    }

    //将变量加入符号表，但先不分配寄存器,需要分配内存
    public void generateMipsInstructionFromIrAlloc() {
        IrAlloc irAlloc = ((IrAlloc) irInstruction);
        MipsSymbol mipsSymbol = new MipsSymbol(irAlloc.getName(),irAlloc.getDimensionNum());
        mipsSymbol.setOffset(mipsSymbolTable.getFpOffset());
        if (irAlloc.getDimensionNum() == 0) {
            mipsSymbolTable.addFpOffset(4);
        } else {
            mipsSymbolTable.addFpOffset(mipsSymbol.getDimensionNum() * 4);
        }
        mipsSymbol.setHasRam(true);
        mipsSymbolTable.addSymbol(mipsSymbol.getName(), mipsSymbol);

    }

    public void generateMipsInstructionFromIrRet() {
        IrRet irRet = ((IrRet) irInstruction);
        if (parentBasicBlock.getParentFunction().getName().equals("main")) {
            mipsInstructions.add(new Li(2, 10));
            mipsInstructions.add(new Syscall());
        } else {
            if (irRet.getOpNum() == 0) { //VOID
                mipsInstructions.add(new Jr(31));
            } else {
                IrValue irValue = irRet.getOperandFromIndex(0);
                int reg;
                if (isConst(irValue.getName())) {
                    mipsInstructions.add(new Li(2, Integer.parseInt(irValue.getName())));
                } else {
                    //直接找到存储该变量的寄存器
                    reg = mipsSymbolTable.getRegIndex(irValue.getName(), mipsInstructions);
                    mipsInstructions.add(new Move(2, reg));
                }
                mipsInstructions.add(new Jr(31));
            }
        }
    }

}
