package backend.instructions;

import backend.RegName;

public class Andi extends MipsInstruction{
    private int destReg;
    private int sourceReg;
    private int imm;
    public Andi(int destReg,int sourceReg,int imm) {
        super("andi");
        this.destReg=destReg;
        this.sourceReg=sourceReg;
        this.imm=imm;
    }
    @Override
    public String toString(){
        StringBuilder sb=new StringBuilder();
        sb.append('\t').append(getName()).append(' ').append(RegName.getInstance().getName(destReg)).append(", ");
        sb.append(RegName.getInstance().getName(sourceReg)).append(", ").append(imm).append('\n');
        return sb.toString();
    }
}
