package backend.instructions;

public class MipsInstruction {
    private String name;
    public MipsInstruction(String name){
        this.name=name;
    }
    public String getName(){
        return name;
    }
}
