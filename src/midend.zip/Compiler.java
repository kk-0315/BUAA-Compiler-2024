
import backend.MipsGenerator;
import backend.MipsModule;
import frontend.ErrorHandler.ErrorHandler;
import frontend.ErrorHandler.Error;
import frontend.lexer.LexicalAnalyzer;
import frontend.lexer.Preprocess;
import frontend.lexer.Token;
import frontend.parser.ParseUnit;
import frontend.parser.Parser;
import frontend.parser.specificUnit.Comp;
import frontend.symbols.Symbol;
import frontend.symbols.SymbolTable;
import midend.IrBuilder;
import midend.IrModule;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class Compiler {
    public static void main(String[] args) throws IOException {
        String path = "testfile.txt"; // 指定文件路径
        StringBuilder contentBuilder = new StringBuilder();

        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = reader.readLine()) != null) {
                contentBuilder.append(line).append("\n"); // 读取每一行并追加换行符
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        Preprocess preprocess = new Preprocess(contentBuilder);
        StringBuilder afterPreProcess = preprocess.process();
        // 将读取的内容转换为String
        String content = afterPreProcess.toString();
        //System.out.println(content);
        LexicalAnalyzer lexicalAnalyzer = new LexicalAnalyzer(content);
        lexicalAnalyzer.parse();
        ArrayList<Token> tokens = lexicalAnalyzer.getTokens();
        Parser parser = new Parser(tokens);

//        System.out.print(parser.getSymbolTable().toString());
//        ErrorHandler.getInstance().sortErrorsByLine();
//        ErrorHandler.getInstance().printErrors();
//        System.out.println(parser.parseCompUnit().toString());
//        parser.parseCompUnit();
//        ErrorHandler.getInstance().sortErrorsByLine();
//        ErrorHandler.getInstance().printErrors();
        //System.out.println(parser.getErrors().toString());
        try {
            Comp comp=parser.parseCompUnit();
            SymbolTable symbolTable = parser.getSymbolTable();
            if (!ErrorHandler.getInstance().getErrors().isEmpty()) {
                ErrorHandler.getInstance().sortErrorsByLine();
                FileWriter fileWriter = new FileWriter("error.txt", false); // true 表示追加写入
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                for (Error error : ErrorHandler.getInstance().getErrors()) {
                    bufferedWriter.write(error.toString());
                    bufferedWriter.newLine(); // 写入换行符
                }
                bufferedWriter.close();
            } else {
                IrBuilder irBuilder=new IrBuilder(comp);
                IrModule irModule=irBuilder.generateIrModule();

                MipsGenerator mipsGenerator=new MipsGenerator(irModule);
                MipsModule mipsModule=mipsGenerator.generateMipsModule();
                String declare="declare i32 @getint()\n" +
                        "declare i32 @getchar()\n" +
                        "declare void @putint(i32)\n" +
                        "declare void @putch(i32)\n" +
                        "declare void @putstr(i8*)\n";


                FileWriter fileWriter1 = new FileWriter("llvm_ir.txt", false); // true 表示追加写入
                BufferedWriter bufferedWriter1 = new BufferedWriter(fileWriter1);
                bufferedWriter1.write(declare);
                bufferedWriter1.write(irModule.toString());
                bufferedWriter1.close();

                FileWriter fileWriter = new FileWriter("symbol.txt", false); // true 表示追加写入
                BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
                bufferedWriter.write(symbolTable.toString());
                bufferedWriter.close();

                FileWriter fileWriter2 = new FileWriter("mips.txt", false); // true 表示追加写入
                BufferedWriter bufferedWriter2 = new BufferedWriter(fileWriter2);
                bufferedWriter2.write(mipsModule.toString());
                bufferedWriter2.close();
            }


        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        // 使用LexicalAnalyzer处理读取的内容
//        LexicalAnalyzer analyzer = new LexicalAnalyzer(content);
//        try {
//            ArrayList<HashMap<Word, String>> result = analyzer.parse();
//            // 输出或处理结果
//        } catch (Exception e) {
//            System.err.println("Error during lexical analysis: " + e.getMessage());
//        }
    }
}
